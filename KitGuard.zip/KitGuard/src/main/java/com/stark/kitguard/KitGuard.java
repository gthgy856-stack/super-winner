package com.stark.kitguard;

import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.inventory.InventoryView;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public class KitGuard extends JavaPlugin {

    private List<String> prefixes = List.of();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        prefixes = getConfig().getStringList("title-prefixes");
        getServer().getPluginManager().registerEvents(new KitGuardListener(this), this);
        getLogger().info("KitGuard enabled — protecting " + prefixes.size() + " title prefix(es).");
    }

    public boolean isProtected(InventoryView view) {
        String title = PlainTextComponentSerializer.plainText().serialize(view.title());
        for (String prefix : prefixes) {
            if (title.startsWith(prefix)) return true;
        }
        return false;
    }
}
