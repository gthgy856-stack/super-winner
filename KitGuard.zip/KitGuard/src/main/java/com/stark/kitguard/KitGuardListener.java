package com.stark.kitguard;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;

public class KitGuardListener implements Listener {

    private final KitGuard plugin;

    public KitGuardListener(KitGuard plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!plugin.isProtected(event.getView())) return;
        if (shouldBlock(event)) {
            event.setCancelled(true);
            refresh(player);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!plugin.isProtected(event.getView())) return;
        int topSize = event.getView().getTopInventory().getSize();
        for (int slot : event.getRawSlots()) {
            if (slot >= topSize) {
                event.setCancelled(true);
                refresh(player);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (!plugin.isProtected(event.getView())) return;
        player.setItemOnCursor(null);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrop(PlayerDropItemEvent event) {
        if (plugin.isProtected(event.getPlayer().getOpenInventory())) {
            event.setCancelled(true);
        }
    }

    private boolean shouldBlock(InventoryClickEvent event) {
        if (event.getClickedInventory() == null) return true;
        if (event.getRawSlot() >= event.getView().getTopInventory().getSize()) return true;

        boolean badClick = switch (event.getClick()) {
            case SHIFT_LEFT, SHIFT_RIGHT, SWAP_OFFHAND, DROP, CONTROL_DROP,
                 NUMBER_KEY, DOUBLE_CLICK, CREATIVE, MIDDLE, UNKNOWN -> true;
            default -> false;
        };
        if (badClick) return true;

        return switch (event.getAction()) {
            case MOVE_TO_OTHER_INVENTORY, HOTBAR_SWAP, HOTBAR_MOVE_AND_READD,
                 COLLECT_TO_CURSOR, CLONE_STACK, DROP_ALL_CURSOR, DROP_ONE_CURSOR,
                 DROP_ALL_SLOT, DROP_ONE_SLOT, UNKNOWN -> true;
            default -> false;
        };
    }

    private void refresh(Player player) {
        plugin.getServer().getScheduler().runTask(plugin, player::updateInventory);
    }
}
